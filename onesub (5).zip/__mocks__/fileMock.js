
// __mocks__/fileMock.js
// Used by Jest to mock static file imports (images, svgs, etc.)

module.exports = 'test-file-stub';
