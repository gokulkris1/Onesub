
import React, { useState, useEffect, FormEvent, Dispatch, SetStateAction } from 'react';
import { Bundle, MockPaymentMethodDetails, Route } from '../types';
import { formatCurrency } from '../utils';
import ServiceItem from '../components/ServiceItem';
import { useAuth } from '../contexts/AuthContext';
import * as paymentService from '../services/paymentService'; 

interface CheckoutPageProps {
  bundle: Bundle;
  onConfirmSubscription: (cycle: 'monthly' | 'annually', pricePaid: number) => Promise<void>;
  navigateTo: (page: Route) => void;
  setLastPaymentError: Dispatch<SetStateAction<string | null>>;
}

const CheckoutPage: React.FC<CheckoutPageProps> = ({ bundle, onConfirmSubscription, navigateTo, setLastPaymentError }) => {
  const { isLoading: authIsLoading, error: authError, currentUser } = useAuth();
  const [selectedCycle, setSelectedCycle] = useState<'monthly' | 'annually'>('monthly');
  const [displayPrice, setDisplayPrice] = useState<number>(bundle.bundlePrice);
  const [effectiveMonthlyPrice, setEffectiveMonthlyPrice] = useState<number | null>(null);
  
  const [paymentIsProcessing, setPaymentIsProcessing] = useState<boolean>(false);
  const [paymentError, setPaymentError] = useState<string | null>(null); // Local error for display on this page
  const [mockClientSecret, setMockClientSecret] = useState<string | null>(null);
  const [cardDetails, setCardDetails] = useState<MockPaymentMethodDetails>({
    cardholderName: currentUser?.fullName || '',
    cardNumber: '',
    expiryDate: '', // MM/YY
    cvc: '',
  });

  useEffect(() => {
    if (selectedCycle === 'annually' && bundle.annualPriceMultiplier) {
      const annualPrice = bundle.bundlePrice * 12 * bundle.annualPriceMultiplier;
      setDisplayPrice(annualPrice);
      setEffectiveMonthlyPrice(annualPrice / 12);
    } else if (selectedCycle === 'annually') { 
      const annualPrice = bundle.bundlePrice * 12;
      setDisplayPrice(annualPrice);
      setEffectiveMonthlyPrice(bundle.bundlePrice);
    }
    else { 
      setDisplayPrice(bundle.bundlePrice);
      setEffectiveMonthlyPrice(null);
    }
  }, [selectedCycle, bundle]);

  useEffect(() => {
    const createIntent = async () => {
        setPaymentIsProcessing(true);
        setPaymentError(null);
        try {
            const intent = await paymentService.createMockPaymentIntent(displayPrice, 'EUR'); 
            setMockClientSecret(intent.clientSecret);
        } catch (err: any) {
            setPaymentError(err.message || "Failed to initialize payment.");
            // Optionally also set global error and navigate if init fails catastrophically
            // setLastPaymentError(err.message || "Failed to initialize payment.");
            // navigateTo('payment-failure');
        } finally {
            setPaymentIsProcessing(false);
        }
    };
    createIntent();
  }, [displayPrice]);

  const handleCardDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPaymentError(null); 
    let { name, value } = e.target;
    if (name === 'cardNumber') {
        value = value.replace(/\D/g, '').slice(0, 16); 
    } else if (name === 'expiryDate') {
        value = value.replace(/\D/g, '').slice(0, 4); 
        if (value.length > 2) {
            value = value.slice(0,2) + '/' + value.slice(2);
        }
    } else if (name === 'cvc') {
        value = value.replace(/\D/g, '').slice(0, 4); 
    }
    setCardDetails(prev => ({ ...prev, [name]: value }));
  };

  const validateCardDetails = (): boolean => {
    if (!cardDetails.cardholderName.trim()) { setPaymentError("Cardholder name is required."); return false; }
    if (cardDetails.cardNumber.length < 13 || cardDetails.cardNumber.length > 16) { setPaymentError("Invalid card number length."); return false; }
    if (!/^\d{2}\/\d{2}$/.test(cardDetails.expiryDate)) { setPaymentError("Expiry date must be MM/YY."); return false; }
    const [month, year] = cardDetails.expiryDate.split('/');
    const expiryMonth = parseInt(month, 10);
    const expiryYear = parseInt(`20${year}`, 10);
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1;
    if (expiryMonth < 1 || expiryMonth > 12) { setPaymentError("Invalid expiry month."); return false;}
    if (expiryYear < currentYear || (expiryYear === currentYear && expiryMonth < currentMonth)) { setPaymentError("Card has expired."); return false; }
    if (cardDetails.cvc.length < 3 || cardDetails.cvc.length > 4) { setPaymentError("Invalid CVC length."); return false; }
    return true;
  };

  const handleConfirm = async (e: FormEvent) => {
    e.preventDefault();
    if (!mockClientSecret) {
        setPaymentError("Payment not initialized. Please wait or refresh.");
        return;
    }
    if (!validateCardDetails()) return;

    setPaymentIsProcessing(true);
    setPaymentError(null);
    try {
      const paymentResult = await paymentService.confirmMockPayment(mockClientSecret, cardDetails);
      if (paymentResult.success) {
        try {
            await onConfirmSubscription(selectedCycle, displayPrice);
            navigateTo('payment-success'); 
        } catch (subscriptionError: any) {
            console.error("Subscription failed after payment:", subscriptionError);
            const errorMessage = subscriptionError.message || "Subscription process failed after payment. Please contact support.";
            setPaymentError(errorMessage); 
            setLastPaymentError(errorMessage); 
            navigateTo('payment-failure');
        }
      } else {
        const errorMessage = paymentResult.error || "Payment failed. Please check your details and try again.";
        setPaymentError(errorMessage); 
        setLastPaymentError(errorMessage);
        navigateTo('payment-failure');
      }
    } catch (err: any) {
      const errorMessage = err.message || "An unexpected error occurred during payment processing.";
      setPaymentError(errorMessage); 
      setLastPaymentError(errorMessage);
      navigateTo('payment-failure');
    } finally {
      setPaymentIsProcessing(false);
    }
  };

  const originalTotalPrice = bundle.services.reduce((sum, service) => sum + service.originalPrice, 0);
  const monthlySavings = originalTotalPrice - bundle.bundlePrice;

  return (
    <form onSubmit={handleConfirm} className="max-w-3xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-2xl">
      <h2 className="text-3xl font-extrabold text-slate-800 mb-6 text-center border-b border-slate-200 pb-4">
        Confirm Your Subscription
      </h2>
      
      <div className="mb-6 p-6 bg-slate-50 rounded-lg">
        <h3 className="text-2xl font-bold text-blue-600 mb-3">{bundle.name}</h3>
        <p className="text-sm text-slate-600 mb-4">{bundle.description}</p>
        
        <h4 className="text-md font-semibold text-slate-700 mb-2">Services Included:</h4>
        <ul className="space-y-1 mb-4">
          {bundle.services.map(service => (
            <ServiceItem key={service.id} service={service} />
          ))}
        </ul>
      </div>

      <div className="mb-6 p-6 bg-slate-50 rounded-lg">
        <h4 className="text-lg font-semibold text-slate-800 mb-3">Choose Billing Cycle:</h4>
        <div className="flex space-x-4 mb-4">
          {['monthly', 'annually'].map((cycle) => (
            <button
              key={cycle}
              type="button"
              onClick={() => setSelectedCycle(cycle as 'monthly' | 'annually')}
              className={`flex-1 py-3 px-4 rounded-md text-sm font-medium transition-all
                ${selectedCycle === cycle 
                  ? 'bg-blue-600 text-white ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-50' 
                  : 'bg-slate-200 hover:bg-slate-300 text-slate-700'}`}
            >
              {cycle === 'monthly' ? 'Monthly' : `Annually ${bundle.annualPriceMultiplier && bundle.annualPriceMultiplier < 1 ? `(Save ${((1 - bundle.annualPriceMultiplier) * 100).toFixed(0)}%)` : ''}`}
            </button>
          ))}
        </div>

        <div className="border-t border-slate-200 pt-4 mt-4">
          <div className="flex justify-between items-baseline mb-1">
            <span className="text-slate-600">Original Monthly Total:</span>
            <span className="text-lg line-through text-slate-500">{formatCurrency(originalTotalPrice)}</span>
          </div>
           <div className="flex justify-between items-baseline mb-1">
            <span className="text-slate-600">Monthly Bundle Price:</span>
            <span className="text-lg text-slate-700">{formatCurrency(bundle.bundlePrice)}</span>
          </div>
          {effectiveMonthlyPrice && selectedCycle === 'annually' && (
            <div className="flex justify-between items-baseline mb-2">
              <span className="text-slate-600">Effective Monthly (Annual Plan):</span>
              <span className="text-lg text-green-600">{formatCurrency(effectiveMonthlyPrice)}</span>
            </div>
          )}
          <div className="flex justify-between items-center my-3">
            <span className="text-xl font-semibold text-green-600">
              {selectedCycle === 'monthly' ? 'Amount Due Today:' : 'Total for 1 Year:'}
            </span>
            <span className="text-3xl font-extrabold text-green-600">
              {formatCurrency(displayPrice)}
            </span>
          </div>
          {monthlySavings > 0 && (
            <p className="text-md font-semibold text-green-700 text-right">
              Monthly Saving: {formatCurrency(monthlySavings)}!
            </p>
          )}
        </div>
      </div>

      <div className="mb-8">
        <h3 className="text-xl font-semibold text-slate-800 mb-4 text-center">Payment Details</h3>
        <div className="p-6 bg-slate-100 rounded-lg space-y-4">
            <div>
                <label htmlFor="cardholderName" className="block text-sm font-medium text-slate-700 mb-1">Cardholder Name</label>
                <input type="text" name="cardholderName" id="cardholderName" value={cardDetails.cardholderName} onChange={handleCardDetailsChange} className="w-full checkout-input-style" required />
            </div>
            <div>
                <label htmlFor="cardNumber" className="block text-sm font-medium text-slate-700 mb-1">Card Number</label>
                <input type="text" name="cardNumber" id="cardNumber" value={cardDetails.cardNumber} onChange={handleCardDetailsChange} className="w-full checkout-input-style" placeholder="•••• •••• •••• ••••" required />
            </div>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <label htmlFor="expiryDate" className="block text-sm font-medium text-slate-700 mb-1">Expiry Date (MM/YY)</label>
                    <input type="text" name="expiryDate" id="expiryDate" value={cardDetails.expiryDate} onChange={handleCardDetailsChange} className="w-full checkout-input-style" placeholder="MM/YY" required />
                </div>
                <div>
                    <label htmlFor="cvc" className="block text-sm font-medium text-slate-700 mb-1">CVC</label>
                    <input type="text" name="cvc" id="cvc" value={cardDetails.cvc} onChange={handleCardDetailsChange} className="w-full checkout-input-style" placeholder="123" required />
                </div>
            </div>
            {!mockClientSecret && !paymentIsProcessing && <p className="text-sm text-yellow-600">Initializing payment gateway...</p>}
        </div>
      </div>

      {/* Display local payment error or general auth error if paymentError is not set */}
      {(paymentError || (!paymentError && authError) ) && (
          <div className="mb-4 p-3 bg-red-100 rounded-md text-center">
            <p className="text-sm text-red-700">{paymentError || authError}</p>
          </div>
      )}

      <button
        type="submit"
        disabled={authIsLoading || paymentIsProcessing || !mockClientSecret}
        className={`w-full ${bundle.themeColor ? bundle.themeColor.replace('border-', 'bg-') : 'bg-blue-600'} 
                    hover:${bundle.themeColor ? bundle.themeColor.replace('border-', 'bg-').replace(/\d00$/, (match) => `${Math.min(9, parseInt(match, 10) / 100 + 1)}00`) : 'hover:bg-blue-700'} 
                    text-white font-semibold py-3 px-6 rounded-lg shadow-md transition-colors duration-200 
                    focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-white 
                    ${bundle.themeColor ? bundle.themeColor.replace('border-', 'focus:ring-') : 'focus:ring-blue-500'}
                    disabled:opacity-50 disabled:cursor-not-allowed`}
      >
        {(authIsLoading || paymentIsProcessing) ? (
          <svg className="animate-spin mx-auto h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : `Confirm & Pay ${formatCurrency(displayPrice)} ${selectedCycle === 'annually' ? ' (Annual)' : '(Monthly)'}`}
      </button>
      <p className="text-xs text-slate-500 mt-4 text-center">
        By clicking "Confirm & Pay", you agree to OneSub's Terms of Service and Privacy Policy.
        (This is a mock action and uses mock card details).
      </p>
      <style>{`
        .checkout-input-style {
          padding: 0.625rem 1rem; 
          background-color: #f8fafc; /* slate-50 */
          border: 1px solid #cbd5e1; /* slate-300 */
          color: #0f172a; /* slate-900 */
          border-radius: 0.375rem; /* rounded-md */
          box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05); /* shadow-sm */
        }
        .checkout-input-style:focus {
          outline: 2px solid transparent;
          outline-offset: 2px;
          border-color: #3b82f6; /* blue-500 */
          box-shadow: 0 0 0 2px #3b82f6; /* ring-2 ring-blue-500 */
        }
      `}</style>
    </form>
  );
};

export default CheckoutPage;
