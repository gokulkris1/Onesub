
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { ProviderApplicationInfo, PlatformUserInfo, AdminProviderInfo } from '../types';
// import AISuggestionBox from '../components/AISuggestionBox'; 
import * as adminService from '../services/adminService';

interface AdminOverviewMetrics {
  totalUsers: number;
  totalActiveProviders: number;
  totalActiveSubscriptions: number;
  mockMRR: number;
}

const AdminDashboardPage: React.FC = () => {
  const { currentUser, adminSuspendUser, adminActivateUser, adminSuspendProvider, adminActivateProvider, isLoading: authIsLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'onboarding' | 'users' | 'providers' | 'aiTools'>('overview');

  const [providerApps, setProviderApps] = useState<ProviderApplicationInfo[]>([]);
  const [platformUsers, setPlatformUsers] = useState<PlatformUserInfo[]>([]);
  const [approvedProviders, setApprovedProviders] = useState<AdminProviderInfo[]>([]);
  const [overviewMetrics, setOverviewMetrics] = useState<AdminOverviewMetrics | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(false);

  const [newProviderForm, setNewProviderForm] = useState({
    businessName: '', contactEmail: '', taxId: '', street: '', city: '', serviceTypes: ''
  });

  const fetchData = async () => {
      if (currentUser?.role === 'admin') {
        setIsLoadingData(true);
        try {
          const [apps, users, providers, metrics] = await Promise.all([
            adminService.getMockProviderApplications(),
            adminService.getMockPlatformUsers(),
            adminService.getMockApprovedProviders(),
            adminService.getMockAdminOverviewMetrics(),
          ]);
          setProviderApps(apps);
          setPlatformUsers(users);
          setApprovedProviders(providers);
          setOverviewMetrics(metrics);
        } catch (error) {
          console.error("Failed to fetch admin dashboard data:", error);
        } finally {
          setIsLoadingData(false);
        }
      }
    };

  useEffect(() => {
    fetchData();
  }, [currentUser]);


  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setNewProviderForm(prev => ({ ...prev, [name]: value }));
  };

  const handleOnboardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser?.email) {
        alert("Admin user email not found, cannot proceed with onboarding notification simulation.");
        return;
    }
    try {
      const onboardedApp = await adminService.onboardNewProvider(newProviderForm, currentUser.email);
      // No need to show alert here, AuthContext will show toast
      setProviderApps(prev => [...prev, onboardedApp]);
       if (onboardedApp.status === 'approved') { // Refresh providers list if new one is auto-approved
           const updatedProviders = await adminService.getMockApprovedProviders();
           setApprovedProviders(updatedProviders);
       }
      setNewProviderForm({ businessName: '', contactEmail: '', taxId: '', street: '', city: '', serviceTypes: '' }); 
    } catch (error: any) {
      // Toast will be shown by AuthContext if adminService throws and auth catches
      console.error(`Failed to onboard provider: ${error.message}`);
    }
  };

  const handleUserStatusChange = async (userId: string, currentStatus: 'active' | 'suspended') => {
    if (!currentUser || currentUser.id === userId) {
        alert("Admins cannot change their own status.");
        return;
    }
    try {
      const updatedUser = currentStatus === 'active' 
        ? await adminSuspendUser(userId) 
        : await adminActivateUser(userId);
      setPlatformUsers(prevUsers => 
        prevUsers.map(u => u.id === userId ? { ...u, status: updatedUser.status } : u)
      );
    } catch (error) {
      // Error toast handled by AuthContext
      console.error("Failed to update user status:", error);
    }
  };

  const handleProviderStatusChange = async (providerId: string, currentStatus: 'active' | 'suspended') => {
     if (!currentUser || currentUser.id === providerId) { // Assuming providerId can be admin's ID if they are also listed as a provider type user
        alert("Admins cannot change their own provider status directly if applicable.");
        return;
    }
    try {
      const updatedProvider = currentStatus === 'active' 
        ? await adminSuspendProvider(providerId) 
        : await adminActivateProvider(providerId);
      setApprovedProviders(prevProviders => 
        prevProviders.map(p => p.id === providerId ? { ...p, status: updatedProvider.status } : p)
      );
    } catch (error) {
      console.error("Failed to update provider status:", error);
    }
  };

  /*
  const generateAdminBundlePrompt = () => {
    return `You are an expert bundle strategist for 'OneSub', a subscription bundling platform. 
    Suggest 3 innovative and marketable new bundle concepts that would appeal to a broad audience or specific niches. 
    For each bundle, please provide: 
    1. A catchy "Name".
    2. A brief "Description" (1-2 sentences).
    3. 2-4 diverse "Service Types" that would complement each other (e.g., Music Streaming, Fitness App, Meal Kits, Educational Content).
    4. A clear "Target Audience" (e.g., Students, Young Professionals, Families, Fitness Enthusiasts).
    Present the information as a numbered list, with each bundle clearly delineated.`;
  };
  */

  if (!currentUser || currentUser.role !== 'admin') {
    return <p className="text-red-600 text-center p-8">Access Denied. You must be an admin to view this page.</p>;
  }

  const renderSection = () => {
    if (isLoadingData) {
        return <p className="text-slate-600 text-center py-10">Loading admin data...</p>;
    }
    switch (activeTab) {
      case 'overview':
        return (
            <div className="space-y-6">
                <h3 className="text-2xl font-semibold text-slate-800 mb-4">Platform Overview</h3>
                {overviewMetrics ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                        <div className="bg-sky-100 p-4 rounded-lg shadow text-sky-800">
                            <p className="text-3xl font-bold">{overviewMetrics.totalUsers.toLocaleString()}</p>
                            <p className="text-sm">Total Users</p>
                        </div>
                        <div className="bg-green-100 p-4 rounded-lg shadow text-green-800">
                            <p className="text-3xl font-bold">{overviewMetrics.totalActiveProviders.toLocaleString()}</p>
                            <p className="text-sm">Active Providers</p>
                        </div>
                        <div className="bg-indigo-100 p-4 rounded-lg shadow text-indigo-800">
                            <p className="text-3xl font-bold">{overviewMetrics.totalActiveSubscriptions.toLocaleString()}</p>
                            <p className="text-sm">Active Subscriptions</p>
                        </div>
                        <div className="bg-amber-100 p-4 rounded-lg shadow text-amber-800">
                            <p className="text-3xl font-bold">€{overviewMetrics.mockMRR.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                            <p className="text-sm">Mock Monthly Recurring Revenue</p>
                        </div>
                    </div>
                ) : (
                    <p>Loading metrics...</p>
                )}
                {/* Placeholder for more charts/data */}
                <div className="mt-6 bg-slate-50 p-4 rounded-lg shadow">
                    <h4 className="text-lg font-medium text-slate-700">Recent Activity (Placeholder)</h4>
                    <p className="text-sm text-slate-500">Graphs and logs will appear here.</p>
                </div>
            </div>
        );
      case 'onboarding':
        return (
          <div className="space-y-8">
            <div>
                <h3 className="text-xl font-semibold text-slate-800 mb-4">Provider Applications</h3>
                <div className="bg-slate-50 p-4 rounded-lg shadow">
                    {providerApps.length > 0 ? (
                        <ul className="divide-y divide-slate-200">
                        {providerApps.map(app => (
                            <li key={app.id} className="py-3 flex justify-between items-center">
                            <div>
                                <p className="font-medium text-slate-700">{app.businessName} <span className={`text-xs px-2 py-0.5 rounded-full ml-2 text-white ${app.status === 'pending' ? 'bg-yellow-500' : app.status === 'approved' ? 'bg-green-500' : 'bg-red-500'}`}>{app.status}</span></p>
                                <p className="text-sm text-slate-500">{app.contactEmail} - Submitted: {new Date(app.dateSubmitted).toLocaleDateString()}</p>
                            </div>
                            <button className="text-sm bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md disabled:opacity-50" disabled>View Details (soon)</button>
                            </li>
                        ))}
                        </ul>
                    ) : <p className="text-slate-500">No pending provider applications.</p>}
                </div>
            </div>
            <div>
              <h3 className="text-xl font-semibold text-slate-800 mb-4">Onboard New Provider</h3>
              <form onSubmit={handleOnboardSubmit} className="bg-slate-50 p-6 rounded-lg shadow space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label htmlFor="businessName" className="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
                        <input type="text" name="businessName" id="businessName" value={newProviderForm.businessName} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" required />
                    </div>
                    <div>
                        <label htmlFor="contactEmail" className="block text-sm font-medium text-slate-700 mb-1">Contact Email</label>
                        <input type="email" name="contactEmail" id="contactEmail" value={newProviderForm.contactEmail} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" required />
                    </div>
                    <div>
                        <label htmlFor="taxId" className="block text-sm font-medium text-slate-700 mb-1">Tax ID / VAT Number</label>
                        <input type="text" name="taxId" id="taxId" value={newProviderForm.taxId} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                     <div>
                        <label htmlFor="street" className="block text-sm font-medium text-slate-700 mb-1">Street Address</label>
                        <input type="text" name="street" id="street" value={newProviderForm.street} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                     <div>
                        <label htmlFor="city" className="block text-sm font-medium text-slate-700 mb-1">City/Town</label>
                        <input type="text" name="city" id="city" value={newProviderForm.city} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                    <div>
                        <label htmlFor="serviceTypes" className="block text-sm font-medium text-slate-700 mb-1">Types of Services Offered (comma-separated)</label>
                        <input type="text" name="serviceTypes" id="serviceTypes" value={newProviderForm.serviceTypes} onChange={handleInputChange} className="w-full bg-white text-slate-900 p-2 rounded-md border border-slate-300 focus:ring-blue-500 focus:border-blue-500" />
                    </div>
                </div>
                <button type="submit" disabled={authIsLoading} className="w-full sm:w-auto px-6 py-2 bg-green-600 hover:bg-green-700 text-white font-semibold rounded-md transition-colors disabled:opacity-50">
                    {authIsLoading ? 'Processing...' : 'Onboard Provider'}
                </button>
              </form>
            </div>
          </div>
        );
      case 'users':
        return (
          <div>
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Platform User Management</h3>
             <div className="bg-slate-50 p-4 rounded-lg shadow overflow-x-auto">
                <table className="w-full min-w-max">
                    <thead>
                        <tr className="text-left border-b border-slate-200">
                            <th className="p-2 text-slate-600">Full Name</th>
                            <th className="p-2 text-slate-600">Email</th>
                            <th className="p-2 text-slate-600">Role</th>
                            <th className="p-2 text-slate-600">Status</th>
                            <th className="p-2 text-slate-600">Registered</th>
                            <th className="p-2 text-slate-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {platformUsers.map(user => (
                            <tr key={user.id} className="border-b border-slate-200 hover:bg-slate-100">
                                <td className="p-2 text-slate-700">{user.fullName}</td>
                                <td className="p-2 text-slate-500">{user.email}</td>
                                <td className="p-2 text-slate-500 capitalize">{user.role}</td>
                                <td className="p-2">
                                    <span className={`px-2 py-0.5 text-xs rounded-full ${user.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {user.status}
                                    </span>
                                </td>
                                <td className="p-2 text-slate-500">{new Date(user.registrationDate).toLocaleDateString()}</td>
                                <td className="p-2">
                                    <button 
                                      onClick={() => handleUserStatusChange(user.id, user.status)}
                                      disabled={authIsLoading || currentUser?.id === user.id}
                                      className={`text-xs px-2 py-1 rounded-md mr-1 disabled:opacity-50 transition-colors
                                        ${user.status === 'active' 
                                          ? 'bg-red-600 hover:bg-red-700 text-white' 
                                          : 'bg-green-600 hover:bg-green-700 text-white'}`}
                                    >
                                      {authIsLoading ? '...' : (user.status === 'active' ? 'Suspend' : 'Activate')}
                                    </button>
                                    <button className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded-md disabled:opacity-50" disabled>Edit (soon)</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
          </div>
        );
      case 'providers':
        return (
          <div>
            <h3 className="text-xl font-semibold text-slate-800 mb-4">Approved Provider Management</h3>
            <div className="bg-slate-50 p-4 rounded-lg shadow overflow-x-auto">
                <table className="w-full min-w-max">
                    <thead>
                        <tr className="text-left border-b border-slate-200">
                            <th className="p-2 text-slate-600">Business Name</th>
                            <th className="p-2 text-slate-600">Contact Email</th>
                            <th className="p-2 text-slate-600">Service Count</th>
                            <th className="p-2 text-slate-600">Status</th>
                            <th className="p-2 text-slate-600">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {approvedProviders.map(provider => (
                            <tr key={provider.id} className="border-b border-slate-200 hover:bg-slate-100">
                                <td className="p-2 text-slate-700">{provider.businessName}</td>
                                <td className="p-2 text-slate-500">{provider.contactEmail}</td>
                                <td className="p-2 text-slate-500 text-center">{provider.serviceCount}</td>
                                <td className="p-2">
                                    <span className={`px-2 py-0.5 text-xs rounded-full ${provider.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                        {provider.status}
                                    </span>
                                </td>
                                <td className="p-2">
                                     <button 
                                      onClick={() => handleProviderStatusChange(provider.id, provider.status)}
                                      disabled={authIsLoading || currentUser?.id === provider.id}
                                      className={`text-xs px-2 py-1 rounded-md mr-1 disabled:opacity-50 transition-colors
                                        ${provider.status === 'active' 
                                          ? 'bg-red-600 hover:bg-red-700 text-white' 
                                          : 'bg-green-600 hover:bg-green-700 text-white'}`}
                                    >
                                      {authIsLoading ? '...' : (provider.status === 'active' ? 'Suspend' : 'Activate')}
                                    </button>
                                    <button className="text-xs bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded-md disabled:opacity-50" disabled>Manage (soon)</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
          </div>
        );
        case 'aiTools':
        return (
          <div className="space-y-8">
            <p className="text-slate-600 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
              AI Suggestion Box feature is currently disabled. A backend proxy (e.g., Firebase Function) needs to be implemented to use AI features.
            </p>
            {/* 
            <AISuggestionBox title="AI-Assisted Bundle Strategy" generatePrompt={generateAdminBundlePrompt} /> 
            */}
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="max-w-6xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-2xl">
      <h2 className="text-3xl font-extrabold text-slate-800 mb-8 text-center border-b border-slate-200 pb-4">
        Admin Panel
      </h2>
      <div className="mb-6 flex flex-wrap border-b border-slate-200">
        {(['overview', 'onboarding', 'users', 'providers', 'aiTools'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-2 sm:px-4 font-medium text-xs sm:text-sm rounded-t-md transition-colors mb-[-1px]
              ${activeTab === tab 
                ? 'bg-blue-600 text-white border-t border-l border-r border-slate-200' 
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-800 border border-transparent'
              }`}
          >
            {tab === 'overview' ? 'Overview' : 
             tab === 'aiTools' ? 'AI & Platform Tools' : 
             `${tab.charAt(0).toUpperCase() + tab.slice(1)} Management`}
          </button>
        ))}
      </div>
      {renderSection()}
       <section className="mt-10 p-6 bg-slate-50 rounded-lg">
        <h3 className="text-xl font-semibold text-slate-800 mb-3">Admin Notification Preferences</h3>
        <div className="space-y-2 text-slate-700">
            <label className="flex items-center space-x-2 hover:text-slate-900 cursor-pointer">
                <input type="checkbox" className="form-checkbox h-4 w-4 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500 disabled:opacity-50" defaultChecked disabled/>
                <span>Email for new user registrations</span>
            </label>
            <label className="flex items-center space-x-2 hover:text-slate-900 cursor-pointer">
                <input type="checkbox" className="form-checkbox h-4 w-4 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500 disabled:opacity-50" defaultChecked disabled/>
                <span>Email for new provider applications</span>
            </label>
             <label className="flex items-center space-x-2 hover:text-slate-900 cursor-pointer">
                <input type="checkbox" className="form-checkbox h-4 w-4 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500 disabled:opacity-50" disabled/>
                <span>Daily platform summary email</span>
            </label>
        </div>
         <p className="text-xs text-slate-500 mt-2">(Notification preference management is a mock UI)</p>
      </section>
    </div>
  );
};

export default AdminDashboardPage;