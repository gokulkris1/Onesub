
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, FullUserProfile, ActiveSubscription, Bundle as BundleType, PlatformUserInfo, AdminProviderInfo } from '../types';
import { MOCK_USERS, BUNDLES_DATA } from '../constants'; 
import { useNotification } from './NotificationContext'; // Import useNotification

import * as authService from '../services/authService';
import * as subscriptionService from '../services/subscriptionService';
import * as adminService from '../services/adminService'; // Import adminService


interface AuthContextType {
  currentUser: User | null;
  isLoading: boolean;
  error: string | null; // This can still be used for inline errors in forms
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string) => Promise<User | null>;
  logout: () => Promise<void>;
  updateUserProfile: (dataToUpdate: Partial<FullUserProfile>, currentPassword?: string, newPassword?: string) => Promise<void>;
  completeMockVerification: (email: string) => Promise<void>;
  requestPasswordResetLink: (email: string) => Promise<string | void>;
  resetUserPassword: (email: string, token: string, newPassword: string) => Promise<void>;
  subscribeToBundle: (bundleId: string, cycle: 'monthly' | 'annually', pricePaid: number) => Promise<void>;
  cancelBundleSubscription: (bundleId: string) => Promise<void>;
  pauseUserSubscription: (bundleId: string, pauseDurationDays: number) => Promise<void>;
  resumeUserSubscription: (bundleId: string) => Promise<void>;
  // Admin actions
  adminSuspendUser: (userId: string) => Promise<PlatformUserInfo>;
  adminActivateUser: (userId: string) => Promise<PlatformUserInfo>;
  adminSuspendProvider: (providerId: string) => Promise<AdminProviderInfo>;
  adminActivateProvider: (providerId: string) => Promise<AdminProviderInfo>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const { addToast } = useNotification(); // Get addToast function

  useEffect(() => {
    setIsLoading(true);
    const storedUser = localStorage.getItem('oneSubUser');
    if (storedUser) {
      try {
        const parsedUser: User = JSON.parse(storedUser);
        setCurrentUser(parsedUser);
      } catch (e) {
        console.error("Failed to parse stored user:", e);
        localStorage.removeItem('oneSubUser');
      }
    }
    setIsLoading(false);
  }, []);

  const updateUserSession = (user: User | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('oneSubUser', JSON.stringify(user));
    } else {
      localStorage.removeItem('oneSubUser');
      localStorage.removeItem('oneSubNewUser'); 
    }
  };

  const login = async (email: string, password: string): Promise<void> => {
    setIsLoading(true);
    setError(null);
    try {
      const user = await authService.loginUser(email, password);
      updateUserSession(user);
      addToast(`Welcome back, ${user.fullName || user.email}!`, 'success');
    } catch (err: any) {
      setError(err.message || 'Login failed.');
      addToast(err.message || 'Login failed.', 'error');
      throw err; 
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (email: string, password: string): Promise<User | null> => {
    setIsLoading(true);
    setError(null);
    try {
      const newUser = await authService.signupUser(email, password);
      addToast('Signup successful! Please verify your email (mock process).', 'success');
      return newUser;
    } catch (err: any) {
      setError(err.message || 'Signup failed.');
      addToast(err.message || 'Signup failed.', 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };
  
  const completeMockVerification = async (email: string): Promise<void> => {
    setIsLoading(true);
    setError(null);
    try {
        await authService.markUserAsVerified(email);
        addToast(`Email ${email} verified successfully! You can now log in.`, 'success');
    } catch (err: any) {
        setError(err.message || "Mock verification failed.");
        addToast(err.message || "Mock verification failed.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    setIsLoading(true);
    setError(null);
    try {
      await authService.logoutUser();
      const userName = currentUser?.fullName || currentUser?.email || "User";
      updateUserSession(null);
      addToast(`Logged out successfully, ${userName}.`, 'info');
    } catch (err: any) {
      setError(err.message || 'Logout failed.');
      addToast(err.message || 'Logout failed.', 'error');
    } finally {
      setIsLoading(false);
    }
  };
  
  const updateUserProfile = async (dataToUpdate: Partial<FullUserProfile>, currentPassword?: string, newPassword?: string): Promise<void> => {
    if (!currentUser) {
        const msg = "You must be logged in to update your profile.";
        setError(msg);
        addToast(msg, 'error');
        throw new Error("User not logged in");
    }
    setIsLoading(true);
    setError(null);
    try {
        const updatedUser = await authService.updateUserProfileData(currentUser, dataToUpdate, currentPassword, newPassword);
        updateUserSession(updatedUser);
        addToast('Profile updated successfully!', 'success');
    } catch (err: any) {
        setError(err.message || "Profile update failed.");
        addToast(err.message || "Profile update failed.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  const requestPasswordResetLink = async (email: string): Promise<string | void> => {
    setIsLoading(true);
    setError(null);
    try {
        const token = await authService.requestPasswordReset(email);
        addToast('If an account exists, a password reset link has been sent (mock).', 'info');
        return token;
    } catch (err: any) {
        setError(err.message || "Requesting password reset failed.");
        addToast(err.message || "Requesting password reset failed.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  const resetUserPassword = async (email: string, token: string, newPassword: string): Promise<void> => {
    setIsLoading(true);
    setError(null);
    try {
        await authService.resetPassword(email, token, newPassword);
        addToast('Password reset successfully! You can now log in.', 'success');
    } catch (err: any) {
        setError(err.message || "Password reset failed.");
        addToast(err.message || "Password reset failed.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };


  const subscribeToBundle = async (bundleId: string, cycle: 'monthly' | 'annually', pricePaid: number): Promise<void> => {
    if (!currentUser) {
      const msg = "You must be logged in to subscribe.";
      setError(msg);
      addToast(msg, 'error');
      throw new Error("User not logged in");
    }
     if (currentUser.isVerified === false) {
      const msg = "Please verify your email before subscribing.";
      setError(msg);
      addToast(msg, 'warning');
      throw new Error(msg);
    }
    setIsLoading(true);
    setError(null);
    try {
      const updatedUser = subscriptionService.addSubscription(currentUser, bundleId, cycle, pricePaid, BUNDLES_DATA);
      updateUserSession(updatedUser);
      const bundleName = BUNDLES_DATA.find(b => b.id === bundleId)?.name || "Selected Bundle";
      addToast(`Successfully subscribed to ${bundleName}!`, 'success');
    } catch (err: any) {
      setError(err.message || "Subscription failed.");
      addToast(err.message || "Subscription failed.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const cancelBundleSubscription = async (bundleId: string): Promise<void> => {
    if (!currentUser) {
      const msg = "You must be logged in to manage subscriptions.";
      setError(msg);
      addToast(msg, 'error');
      throw new Error("User not logged in");
    }
    setIsLoading(true);
    setError(null);
    try {
      const updatedUser = subscriptionService.removeSubscription(currentUser, bundleId, BUNDLES_DATA);
      updateUserSession(updatedUser);
      const bundleName = BUNDLES_DATA.find(b => b.id === bundleId)?.name || "Selected Bundle";
      addToast(`Subscription to ${bundleName} canceled.`, 'info');
    } catch (err: any) {
      setError(err.message || "Cancellation failed.");
      addToast(err.message || "Cancellation failed.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const pauseUserSubscription = async (bundleId: string, pauseDurationDays: number): Promise<void> => {
    if (!currentUser) {
        const msg = "User not logged in";
        setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
        const updatedUser = subscriptionService.pauseUserSubscription(currentUser, bundleId, pauseDurationDays, BUNDLES_DATA);
        updateUserSession(updatedUser);
        const bundleName = BUNDLES_DATA.find(b => b.id === bundleId)?.name || "Subscription";
        addToast(`${bundleName} paused successfully.`, 'success');
    } catch (err: any) {
        setError(err.message || "Failed to pause subscription.");
        addToast(err.message || "Failed to pause subscription.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  const resumeUserSubscription = async (bundleId: string): Promise<void> => {
     if (!currentUser) {
        const msg = "User not logged in";
        setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
        const updatedUser = subscriptionService.resumeUserSubscription(currentUser, bundleId, BUNDLES_DATA);
        updateUserSession(updatedUser);
        const bundleName = BUNDLES_DATA.find(b => b.id === bundleId)?.name || "Subscription";
        addToast(`${bundleName} resumed successfully.`, 'success');
    } catch (err: any) {
        setError(err.message || "Failed to resume subscription.");
        addToast(err.message || "Failed to resume subscription.", 'error');
        throw err;
    } finally {
        setIsLoading(false);
    }
  };

  // Admin Actions
  const adminSuspendUser = async (userId: string): Promise<PlatformUserInfo> => {
    if (!currentUser || currentUser.role !== 'admin') {
      const msg = "Unauthorized action.";
      setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
      const updatedUserInfo = await adminService.suspendUser(userId, currentUser.email);
      addToast(`User ${updatedUserInfo.fullName || updatedUserInfo.email} suspended.`, 'success');
      return updatedUserInfo;
    } catch (err: any) {
      setError(err.message || "Failed to suspend user.");
      addToast(err.message || "Failed to suspend user.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const adminActivateUser = async (userId: string): Promise<PlatformUserInfo> => {
    if (!currentUser || currentUser.role !== 'admin') {
      const msg = "Unauthorized action.";
      setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
      const updatedUserInfo = await adminService.activateUser(userId, currentUser.email);
      addToast(`User ${updatedUserInfo.fullName || updatedUserInfo.email} activated.`, 'success');
      return updatedUserInfo;
    } catch (err: any) {
      setError(err.message || "Failed to activate user.");
      addToast(err.message || "Failed to activate user.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const adminSuspendProvider = async (providerId: string): Promise<AdminProviderInfo> => {
     if (!currentUser || currentUser.role !== 'admin') {
      const msg = "Unauthorized action.";
      setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
      const updatedProviderInfo = await adminService.suspendProvider(providerId, currentUser.email);
      addToast(`Provider ${updatedProviderInfo.businessName} suspended.`, 'success');
      return updatedProviderInfo;
    } catch (err: any) {
      setError(err.message || "Failed to suspend provider.");
      addToast(err.message || "Failed to suspend provider.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const adminActivateProvider = async (providerId: string): Promise<AdminProviderInfo> => {
    if (!currentUser || currentUser.role !== 'admin') {
      const msg = "Unauthorized action.";
      setError(msg); addToast(msg, 'error'); throw new Error(msg);
    }
    setIsLoading(true); setError(null);
    try {
      const updatedProviderInfo = await adminService.activateProvider(providerId, currentUser.email);
      addToast(`Provider ${updatedProviderInfo.businessName} activated.`, 'success');
      return updatedProviderInfo;
    } catch (err: any) {
      setError(err.message || "Failed to activate provider.");
      addToast(err.message || "Failed to activate provider.", 'error');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    currentUser,
    isLoading,
    error,
    login,
    signup,
    logout,
    updateUserProfile,
    completeMockVerification,
    requestPasswordResetLink,
    resetUserPassword,
    subscribeToBundle,
    cancelBundleSubscription,
    pauseUserSubscription,
    resumeUserSubscription,
    adminSuspendUser,
    adminActivateUser,
    adminSuspendProvider,
    adminActivateProvider,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
